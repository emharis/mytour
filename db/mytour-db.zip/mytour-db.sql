-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.39 - Source distribution
-- Server OS:                    Linux
-- HeidiSQL Version:             9.2.0.4947
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for web_mytour
DROP DATABASE IF EXISTS `web_mytour`;
CREATE DATABASE IF NOT EXISTS `web_mytour` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `web_mytour`;


-- Dumping structure for table web_mytour.aboutpage
DROP TABLE IF EXISTS `aboutpage`;
CREATE TABLE IF NOT EXISTS `aboutpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `big_value` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.banner
DROP TABLE IF EXISTS `banner`;
CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.blog
DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `tags` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `img_cover` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '570*222',
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.blog_category
DROP TABLE IF EXISTS `blog_category`;
CREATE TABLE IF NOT EXISTS `blog_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.comments
DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `content` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT NULL,
  `author` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blog_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_comments_blog` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.constval
DROP TABLE IF EXISTS `constval`;
CREATE TABLE IF NOT EXISTS `constval` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.contactpage
DROP TABLE IF EXISTS `contactpage`;
CREATE TABLE IF NOT EXISTS `contactpage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `big_value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.destinasi
DROP TABLE IF EXISTS `destinasi`;
CREATE TABLE IF NOT EXISTS `destinasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destinasi_kategori_id` int(11) DEFAULT NULL,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  `nama` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` mediumtext COLLATE utf8_unicode_ci,
  `main_img` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_destinasi_destinasi_kategori` (`destinasi_kategori_id`),
  CONSTRAINT `FK_destinasi_destinasi_kategori` FOREIGN KEY (`destinasi_kategori_id`) REFERENCES `destinasi_kategori` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.destinasi_image
DROP TABLE IF EXISTS `destinasi_image`;
CREATE TABLE IF NOT EXISTS `destinasi_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `destinasi_id` int(11) NOT NULL DEFAULT '0',
  `type` enum('I','V') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'I' COMMENT 'I: Image, V:Video',
  `islocal` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_img` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  `vidthumb` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_destinasi_image_destinasi` (`destinasi_id`),
  CONSTRAINT `FK_destinasi_image_destinasi` FOREIGN KEY (`destinasi_id`) REFERENCES `destinasi` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.destinasi_kategori
DROP TABLE IF EXISTS `destinasi_kategori`;
CREATE TABLE IF NOT EXISTS `destinasi_kategori` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.gallery
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `type` enum('I','V') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'I:Image, V:Video',
  `isexternal` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  `title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.homepage
DROP TABLE IF EXISTS `homepage`;
CREATE TABLE IF NOT EXISTS `homepage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `big_value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.homepage_hotel
DROP TABLE IF EXISTS `homepage_hotel`;
CREATE TABLE IF NOT EXISTS `homepage_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.homepage_rental
DROP TABLE IF EXISTS `homepage_rental`;
CREATE TABLE IF NOT EXISTS `homepage_rental` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rental_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.homepage_slider
DROP TABLE IF EXISTS `homepage_slider`;
CREATE TABLE IF NOT EXISTS `homepage_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.homepage_travelpack
DROP TABLE IF EXISTS `homepage_travelpack`;
CREATE TABLE IF NOT EXISTS `homepage_travelpack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `travelpack_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.hotel
DROP TABLE IF EXISTS `hotel`;
CREATE TABLE IF NOT EXISTS `hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `img_cover` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `alamat` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `desc` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.hotel_image
DROP TABLE IF EXISTS `hotel_image`;
CREATE TABLE IF NOT EXISTS `hotel_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) DEFAULT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_img` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  `islocal` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.hotel_room
DROP TABLE IF EXISTS `hotel_room`;
CREATE TABLE IF NOT EXISTS `hotel_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) DEFAULT NULL,
  `nama` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `harga` decimal(10,2) DEFAULT NULL,
  `currency` enum('IDR','USD') COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'Y',
  `img_cover` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hotel_image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.menu
DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `tipe_id` int(11) DEFAULT NULL,
  `position` enum('T','B','A') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'T;Top, B:Bottom,A:All',
  `order` int(11) DEFAULT NULL,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'Y',
  `link` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_menu_tipe_menu` (`tipe_id`),
  CONSTRAINT `FK_menu_tipe_menu` FOREIGN KEY (`tipe_id`) REFERENCES `tipe_menu` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.permissions
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `permissions_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.permission_role
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE IF NOT EXISTS `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `permission_role_permission_id_index` (`permission_id`),
  KEY `permission_role_role_id_index` (`role_id`),
  CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.rental
DROP TABLE IF EXISTS `rental`;
CREATE TABLE IF NOT EXISTS `rental` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` text COLLATE utf8_unicode_ci,
  `harga` decimal(10,2) DEFAULT NULL,
  `currency` enum('IDR','USD') COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.rental_image
DROP TABLE IF EXISTS `rental_image`;
CREATE TABLE IF NOT EXISTS `rental_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rental_id` int(11) DEFAULT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `main_img` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.roles
DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `roles_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.role_user
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `role_user_user_id_index` (`user_id`),
  KEY `role_user_role_id_index` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.testimony
DROP TABLE IF EXISTS `testimony`;
CREATE TABLE IF NOT EXISTS `testimony` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `nama` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.tipe_menu
DROP TABLE IF EXISTS `tipe_menu`;
CREATE TABLE IF NOT EXISTS `tipe_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.travelpack
DROP TABLE IF EXISTS `travelpack`;
CREATE TABLE IF NOT EXISTS `travelpack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `harga` decimal(10,2) DEFAULT NULL,
  `currency` enum('IDR','USD') COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` mediumtext COLLATE utf8_unicode_ci,
  `publish` enum('Y','N') COLLATE utf8_unicode_ci DEFAULT 'Y',
  `include` text COLLATE utf8_unicode_ci,
  `exclude` text COLLATE utf8_unicode_ci,
  `itinerary` text COLLATE utf8_unicode_ci,
  `day` int(11) DEFAULT NULL,
  `night` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.travelpack_hotel
DROP TABLE IF EXISTS `travelpack_hotel`;
CREATE TABLE IF NOT EXISTS `travelpack_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `travelpack_id` int(11) NOT NULL DEFAULT '0',
  `hotel_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.travelpack_image
DROP TABLE IF EXISTS `travelpack_image`;
CREATE TABLE IF NOT EXISTS `travelpack_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `travelpack_id` int(11) NOT NULL,
  `filename` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `main_img` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `is_local` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.travelpack_include
DROP TABLE IF EXISTS `travelpack_include`;
CREATE TABLE IF NOT EXISTS `travelpack_include` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `travelpack_id` int(11) DEFAULT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `desc` text COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('I','E','T') COLLATE utf8_unicode_ci NOT NULL COMMENT 'I : Include, E:Exclude,T:Itenerary',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for table web_mytour.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `salt` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_username_index` (`username`),
  KEY `users_password_index` (`password`),
  KEY `users_email_index` (`email`),
  KEY `users_remember_token_index` (`remember_token`),
  KEY `users_deleted_at_index` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Data exporting was unselected.


-- Dumping structure for view web_mytour.view_blogs
DROP VIEW IF EXISTS `view_blogs`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_blogs` (
	`id` INT(11) NOT NULL,
	`created_at` DATETIME NULL,
	`title` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`content` MEDIUMTEXT NULL COLLATE 'utf8_unicode_ci',
	`tags` VARCHAR(150) NULL COLLATE 'utf8_unicode_ci',
	`publish` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`author_id` INT(11) NULL,
	`img_cover` VARCHAR(150) NULL COMMENT '570*222' COLLATE 'utf8_unicode_ci',
	`username` VARCHAR(30) NULL COLLATE 'utf8_unicode_ci',
	`kategori` VARCHAR(100) NULL COLLATE 'utf8_unicode_ci',
	`category_id` INT(11) NULL
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_destinasi
DROP VIEW IF EXISTS `view_destinasi`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_destinasi` (
	`id` INT(11) NOT NULL,
	`destinasi_kategori_id` INT(11) NULL,
	`kategori` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`deskat_img` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`publish` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`nama` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`desc` MEDIUMTEXT NULL COLLATE 'utf8_unicode_ci',
	`main_img` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.VIEW_DESTINASI_KATEGORI
DROP VIEW IF EXISTS `VIEW_DESTINASI_KATEGORI`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `VIEW_DESTINASI_KATEGORI` (
	`id` INT(11) NOT NULL,
	`nama` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`filename` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`destinasi_sum` DECIMAL(32,0) NULL
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_homepage_hotel
DROP VIEW IF EXISTS `view_homepage_hotel`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_homepage_hotel` (
	`id` INT(11) NOT NULL,
	`hotel_id` INT(11) NOT NULL,
	`nama` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`room` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`harga` DECIMAL(10,2) NULL,
	`currency` ENUM('IDR','USD') NULL COLLATE 'utf8_unicode_ci',
	`filename` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.VIEW_HOMEPAGE_TRAVEL
DROP VIEW IF EXISTS `VIEW_HOMEPAGE_TRAVEL`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `VIEW_HOMEPAGE_TRAVEL` (
	`id` INT(11) NOT NULL,
	`travelpack_id` INT(11) NULL,
	`nama` VARCHAR(150) NULL COLLATE 'utf8_unicode_ci',
	`harga` DECIMAL(10,2) NULL,
	`currency` ENUM('IDR','USD') NULL COLLATE 'utf8_unicode_ci',
	`desc` MEDIUMTEXT NULL COLLATE 'utf8_unicode_ci',
	`publish` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`include` TEXT NULL COLLATE 'utf8_unicode_ci',
	`exclude` TEXT NULL COLLATE 'utf8_unicode_ci',
	`itinerary` TEXT NULL COLLATE 'utf8_unicode_ci',
	`day` INT(11) NULL,
	`night` INT(11) NULL
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_hotel
DROP VIEW IF EXISTS `view_hotel`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_hotel` (
	`id` INT(11) NOT NULL,
	`nama` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`alamat` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`desc` MEDIUMTEXT NOT NULL COLLATE 'utf8_unicode_ci',
	`imgpath` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`img_cover` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`jumlah_room` BIGINT(21) NULL
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_rental
DROP VIEW IF EXISTS `view_rental`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_rental` (
	`id` INT(11) NOT NULL,
	`nama` VARCHAR(150) NULL COLLATE 'utf8_unicode_ci',
	`desc` TEXT NULL COLLATE 'utf8_unicode_ci',
	`currency` ENUM('IDR','USD') NULL COLLATE 'utf8_unicode_ci',
	`harga` DECIMAL(10,2) NULL,
	`filename` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_travel
DROP VIEW IF EXISTS `view_travel`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_travel` (
	`id` INT(11) NOT NULL,
	`nama` VARCHAR(150) NULL COLLATE 'utf8_unicode_ci',
	`harga` DECIMAL(10,2) NULL,
	`currency` ENUM('IDR','USD') NULL COLLATE 'utf8_unicode_ci',
	`day` INT(11) NULL,
	`night` INT(11) NULL,
	`desc` MEDIUMTEXT NULL COLLATE 'utf8_unicode_ci',
	`publish` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`filename` VARCHAR(250) NULL COLLATE 'utf8_unicode_ci',
	`main_img` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`include` TEXT NULL COLLATE 'utf8_unicode_ci',
	`exclude` TEXT NULL COLLATE 'utf8_unicode_ci',
	`itinerary` TEXT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_travelpack_hotel
DROP VIEW IF EXISTS `view_travelpack_hotel`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_travelpack_hotel` (
	`id` INT(11) NOT NULL,
	`travelpack_id` INT(11) NOT NULL,
	`nama` VARCHAR(150) NULL COLLATE 'utf8_unicode_ci',
	`harga` DECIMAL(10,2) NULL,
	`currency` ENUM('IDR','USD') NULL COLLATE 'utf8_unicode_ci',
	`desc` MEDIUMTEXT NULL COLLATE 'utf8_unicode_ci',
	`publish` ENUM('Y','N') NULL COLLATE 'utf8_unicode_ci',
	`include` TEXT NULL COLLATE 'utf8_unicode_ci',
	`exclude` TEXT NULL COLLATE 'utf8_unicode_ci',
	`itinerary` TEXT NULL COLLATE 'utf8_unicode_ci',
	`hotel_id` INT(11) NOT NULL,
	`hotel` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`img_cover` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`alamat` VARCHAR(250) NOT NULL COLLATE 'utf8_unicode_ci',
	`desc_hotel` MEDIUMTEXT NOT NULL COLLATE 'utf8_unicode_ci'
) ENGINE=MyISAM;


-- Dumping structure for view web_mytour.view_blogs
DROP VIEW IF EXISTS `view_blogs`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_blogs`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_blogs` AS select `blog`.`id` AS `id`,`blog`.`created_at` AS `created_at`,`blog`.`title` AS `title`,`blog`.`content` AS `content`,`blog`.`tags` AS `tags`,`blog`.`publish` AS `publish`,`blog`.`author_id` AS `author_id`,`blog`.`img_cover` AS `img_cover`,`users`.`username` AS `username`,`blog_category`.`name` AS `kategori`,`blog`.`category_id` AS `category_id` from ((`blog` join `blog_category` on((`blog`.`category_id` = `blog_category`.`id`))) left join `users` on((`blog`.`author_id` = `users`.`id`))) order by `blog`.`created_at` desc;


-- Dumping structure for view web_mytour.view_destinasi
DROP VIEW IF EXISTS `view_destinasi`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_destinasi`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_destinasi` AS select `dest`.`id` AS `id`,`dest`.`destinasi_kategori_id` AS `destinasi_kategori_id`,`deskat`.`nama` AS `kategori`,`deskat`.`filename` AS `deskat_img`,`dest`.`publish` AS `publish`,`dest`.`nama` AS `nama`,`dest`.`desc` AS `desc`,`dest`.`main_img` AS `main_img` from (`destinasi` `dest` join `destinasi_kategori` `deskat` on((`dest`.`destinasi_kategori_id` = `deskat`.`id`)));


-- Dumping structure for view web_mytour.VIEW_DESTINASI_KATEGORI
DROP VIEW IF EXISTS `VIEW_DESTINASI_KATEGORI`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `VIEW_DESTINASI_KATEGORI`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `VIEW_DESTINASI_KATEGORI` AS select `dk`.`id` AS `id`,`dk`.`nama` AS `nama`,`dk`.`filename` AS `filename`,(select sum(`dt`.`id`) from `destinasi` `dt` where (`dt`.`destinasi_kategori_id` = `dk`.`id`)) AS `destinasi_sum` from `destinasi_kategori` `dk`;


-- Dumping structure for view web_mytour.view_homepage_hotel
DROP VIEW IF EXISTS `view_homepage_hotel`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_homepage_hotel`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_homepage_hotel` AS select `homepage_hotel`.`id` AS `id`,`hotel`.`id` AS `hotel_id`,`hotel`.`nama` AS `nama`,`hotel_room`.`nama` AS `room`,`hotel_room`.`harga` AS `harga`,`hotel_room`.`currency` AS `currency`,`hotel`.`img_cover` AS `filename` from ((`homepage_hotel` join `hotel` on((`homepage_hotel`.`hotel_id` = `hotel`.`id`))) left join `hotel_room` on((`hotel_room`.`hotel_id` = `hotel`.`id`)));


-- Dumping structure for view web_mytour.VIEW_HOMEPAGE_TRAVEL
DROP VIEW IF EXISTS `VIEW_HOMEPAGE_TRAVEL`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `VIEW_HOMEPAGE_TRAVEL`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `VIEW_HOMEPAGE_TRAVEL` AS select `ht`.`id` AS `id`,`ht`.`travelpack_id` AS `travelpack_id`,`tp`.`nama` AS `nama`,`tp`.`harga` AS `harga`,`tp`.`currency` AS `currency`,`tp`.`desc` AS `desc`,`tp`.`publish` AS `publish`,`tp`.`include` AS `include`,`tp`.`exclude` AS `exclude`,`tp`.`itinerary` AS `itinerary`,`tp`.`day` AS `day`,`tp`.`night` AS `night` from (`homepage_travelpack` `ht` join `travelpack` `tp`);


-- Dumping structure for view web_mytour.view_hotel
DROP VIEW IF EXISTS `view_hotel`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_hotel`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_hotel` AS select `hotel`.`id` AS `id`,`hotel`.`nama` AS `nama`,`hotel`.`alamat` AS `alamat`,`hotel`.`desc` AS `desc`,(select `constval`.`value` from `constval` where (`constval`.`name` = 'hotel_img_path')) AS `imgpath`,`hotel`.`img_cover` AS `img_cover`,(select count(`hotel_room`.`id`) from `hotel_room` where (`hotel_room`.`hotel_id` = `hotel`.`id`)) AS `jumlah_room` from `hotel`;


-- Dumping structure for view web_mytour.view_rental
DROP VIEW IF EXISTS `view_rental`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_rental`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_rental` AS select `rt`.`id` AS `id`,`rt`.`nama` AS `nama`,`rt`.`desc` AS `desc`,`rt`.`currency` AS `currency`,`rt`.`harga` AS `harga`,`ri`.`filename` AS `filename` from (`rental` `rt` join `rental_image` `ri` on((`rt`.`id` = `ri`.`rental_id`))) where (`ri`.`main_img` = 'Y');


-- Dumping structure for view web_mytour.view_travel
DROP VIEW IF EXISTS `view_travel`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_travel`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_travel` AS select `tv`.`id` AS `id`,`tv`.`nama` AS `nama`,`tv`.`harga` AS `harga`,`tv`.`currency` AS `currency`,`tv`.`day` AS `day`,`tv`.`night` AS `night`,`tv`.`desc` AS `desc`,`tv`.`publish` AS `publish`,`tim`.`filename` AS `filename`,`tim`.`main_img` AS `main_img`,`tv`.`include` AS `include`,`tv`.`exclude` AS `exclude`,`tv`.`itinerary` AS `itinerary` from (`travelpack` `tv` left join `travelpack_image` `tim` on((`tim`.`travelpack_id` = `tv`.`id`))) where (`tim`.`main_img` = 'Y');


-- Dumping structure for view web_mytour.view_travelpack_hotel
DROP VIEW IF EXISTS `view_travelpack_hotel`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_travelpack_hotel`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_travelpack_hotel` AS select `th`.`id` AS `id`,`th`.`travelpack_id` AS `travelpack_id`,`tp`.`nama` AS `nama`,`tp`.`harga` AS `harga`,`tp`.`currency` AS `currency`,`tp`.`desc` AS `desc`,`tp`.`publish` AS `publish`,`tp`.`include` AS `include`,`tp`.`exclude` AS `exclude`,`tp`.`itinerary` AS `itinerary`,`ht`.`id` AS `hotel_id`,`ht`.`nama` AS `hotel`,`ht`.`img_cover` AS `img_cover`,`ht`.`alamat` AS `alamat`,`ht`.`desc` AS `desc_hotel` from ((`travelpack_hotel` `th` join `travelpack` `tp` on((`th`.`travelpack_id` = `tp`.`id`))) join `hotel` `ht` on((`th`.`hotel_id` = `ht`.`id`)));
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
